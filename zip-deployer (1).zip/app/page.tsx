"use client"

import type React from "react"

import { useState } from "react"
import { Download, Video, Loader2, AlertCircle, CheckCircle, Copy, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/hooks/use-toast"

interface VideoData {
  video: {
    noWatermark: string
    withWatermark?: string
  }
  music?: {
    play_url: string
    title: string
  }
  author?: {
    nickname: string
    unique_id: string
  }
  title?: string
}

interface DownloadState {
  loading: boolean
  error: string | null
  videoData: VideoData | null
}

export default function TikTokDownloader() {
  const [url, setUrl] = useState("")
  const [state, setState] = useState<DownloadState>({
    loading: false,
    error: null,
    videoData: null,
  })

  const isValidTikTokUrl = (url: string): boolean => {
    const domains = ["tiktok.com", "vm.tiktok.com", "vt.tiktok.com"]
    return domains.some((domain) => url.includes(domain))
  }

  const downloadVideo = async () => {
    if (!url.trim()) {
      setState((prev) => ({ ...prev, error: "Masukkan link TikTok terlebih dahulu!" }))
      return
    }

    if (!isValidTikTokUrl(url)) {
      setState((prev) => ({ ...prev, error: "Link TikTok tidak valid!" }))
      return
    }

    setState({ loading: true, error: null, videoData: null })

    try {
      const response = await fetch(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`)
      const data = await response.json()

      if (data && data.video && data.video.noWatermark) {
        setState({
          loading: false,
          error: null,
          videoData: data,
        })
        toast({
          title: "Berhasil!",
          description: "Video berhasil diproses dan siap diunduh.",
        })
      } else {
        throw new Error(data.message || "Gagal mengambil video")
      }
    } catch (error) {
      setState({
        loading: false,
        error: error instanceof Error ? error.message : "Terjadi kesalahan saat mengunduh video",
        videoData: null,
      })
      toast({
        title: "Error",
        description: "Gagal memproses video. Silakan coba lagi.",
        variant: "destructive",
      })
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      downloadVideo()
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Tersalin!",
        description: "Link berhasil disalin ke clipboard.",
      })
    } catch (error) {
      console.error("Failed to copy:", error)
    }
  }

  const clearForm = () => {
    setUrl("")
    setState({ loading: false, error: null, videoData: null })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-teal-50 p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Video className="h-10 w-10 text-pink-500" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-teal-500 bg-clip-text text-transparent">
              TikTok Downloader
            </h1>
          </div>
          <p className="text-gray-600 text-lg">Download video TikTok tanpa watermark dengan mudah dan gratis</p>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
            <Badge variant="secondary">✨ Tanpa Watermark</Badge>
            <Badge variant="secondary">🚀 Cepat & Mudah</Badge>
            <Badge variant="secondary">💯 Gratis</Badge>
          </div>
        </div>

        {/* Main Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-pink-500" />
              Download Video
            </CardTitle>
            <CardDescription>Masukkan link TikTok untuk mengunduh video tanpa watermark</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="https://www.tiktok.com/@username/video/..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="text-base pr-20"
                />
                {url && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearForm}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    ✕
                  </Button>
                )}
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={downloadVideo}
                  disabled={state.loading || !url.trim()}
                  className="flex-1 bg-pink-500 hover:bg-pink-600"
                >
                  {state.loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Memproses...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4 mr-2" />
                      Download Video
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Error Alert */}
            {state.error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{state.error}</AlertDescription>
              </Alert>
            )}

            {/* Success Result */}
            {state.videoData && (
              <div className="space-y-4 animate-in fade-in-50 duration-500">
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    Video berhasil diproses! Klik tombol download di bawah.
                  </AlertDescription>
                </Alert>

                {/* Video Preview */}
                <div className="space-y-4">
                  <video
                    controls
                    className="w-full rounded-lg shadow-lg max-h-96"
                    src={state.videoData.video.noWatermark}
                    preload="metadata"
                    poster="/placeholder.svg?height=400&width=600"
                  >
                    Browser Anda tidak mendukung video HTML5.
                  </video>

                  {/* Video Info */}
                  {state.videoData.author && (
                    <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2 text-sm">
                        <Badge variant="outline" className="bg-white">
                          @{state.videoData.author.unique_id}
                        </Badge>
                        {state.videoData.author.nickname && (
                          <span className="text-gray-600">{state.videoData.author.nickname}</span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Download Buttons */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Button asChild className="bg-purple-500 hover:bg-purple-600 h-12">
                      <a
                        href={state.videoData.video.noWatermark}
                        download
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Tanpa Watermark
                      </a>
                    </Button>
                    <Button asChild variant="outline" className="border-teal-500 text-teal-600 hover:bg-teal-50 h-12">
                      <a
                        href={state.videoData.video.withWatermark || state.videoData.video.noWatermark}
                        download
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2"
                      >
                        <Video className="h-4 w-4" />
                        Versi Original
                      </a>
                    </Button>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(state.videoData!.video.noWatermark)}
                      className="flex-1"
                    >
                      <Copy className="h-3 w-3 mr-1" />
                      Salin Link
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(state.videoData!.video.noWatermark, "_blank")}
                      className="flex-1"
                    >
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Buka di Tab Baru
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-pink-500">📋 Cara Download Video TikTok</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800">Langkah-langkah:</h4>
                <ol className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 text-xs min-w-[20px] justify-center">
                      1
                    </Badge>
                    <span>Buka aplikasi TikTok dan temukan video yang ingin diunduh</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 text-xs min-w-[20px] justify-center">
                      2
                    </Badge>
                    <span>Tap tombol "Bagikan" dan pilih "Salin tautan"</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 text-xs min-w-[20px] justify-center">
                      3
                    </Badge>
                    <span>Tempel link di kolom input di atas</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 text-xs min-w-[20px] justify-center">
                      4
                    </Badge>
                    <span>Klik "Download Video" dan tunggu prosesnya</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 text-xs min-w-[20px] justify-center">
                      5
                    </Badge>
                    <span>Pilih versi tanpa watermark untuk diunduh</span>
                  </li>
                </ol>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800">Fitur Unggulan:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✓</span>
                    <span>Download tanpa watermark</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✓</span>
                    <span>Kualitas video HD</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✓</span>
                    <span>Gratis tanpa batas</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✓</span>
                    <span>Tidak perlu registrasi</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✓</span>
                    <span>Aman dan privat</span>
                  </li>
                </ul>
              </div>
            </div>

            <Alert className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Penting:</strong> Video diambil langsung dari server TikTok. Kami tidak menyimpan atau menyalin
                konten apapun. Gunakan dengan bijak dan hormati hak cipta pembuat konten.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <div className="text-sm text-gray-500">
            © {new Date().getFullYear()} TikTok Downloader. Dibuat dengan ❤️ untuk kemudahan Anda.
          </div>
          <div className="text-xs text-gray-400">
            Tidak berafiliasi dengan TikTok Inc. Gunakan dengan bijak dan hormati hak cipta.
          </div>
        </div>
      </div>
    </div>
  )
}
