import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "TikTok Downloader - Download Video Tanpa Watermark Gratis",
  description:
    "Download video TikTok tanpa watermark dengan mudah, cepat, dan gratis. Kualitas HD, tanpa batas, dan aman digunakan.",
  keywords: "tiktok downloader, download tiktok, video tanpa watermark, tiktok gratis, download video tiktok",
  authors: [{ name: "TikTok Downloader" }],
  creator: "TikTok Downloader",
  publisher: "TikTok Downloader",
  robots: "index, follow",
  openGraph: {
    title: "TikTok Downloader - Download Video Tanpa Watermark",
    description: "Download video TikTok tanpa watermark dengan mudah dan gratis",
    type: "website",
    locale: "id_ID",
  },
  twitter: {
    card: "summary_large_image",
    title: "TikTok Downloader - Download Video Tanpa Watermark",
    description: "Download video TikTok tanpa watermark dengan mudah dan gratis",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="id">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#fe2c55" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="TikTok Downloader" />
      </head>
      <body className={inter.className}>
        {children}
        <Toaster />
      </body>
    </html>
  )
}
