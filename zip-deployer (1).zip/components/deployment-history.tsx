"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Calendar, FileArchive } from "lucide-react"

interface Deployment {
  id: string
  name: string
  url: string
  status: "success" | "failed" | "building"
  createdAt: string
  size: string
}

const mockDeployments: Deployment[] = [
  {
    id: "1",
    name: "my-react-app.zip",
    url: "https://my-react-app-abc123.vercel.app",
    status: "success",
    createdAt: "2024-01-15T10:30:00Z",
    size: "2.4 MB",
  },
  {
    id: "2",
    name: "portfolio-site.zip",
    url: "https://portfolio-site-def456.vercel.app",
    status: "success",
    createdAt: "2024-01-14T15:45:00Z",
    size: "1.8 MB",
  },
  {
    id: "3",
    name: "dashboard-app.zip",
    url: "https://dashboard-app-ghi789.vercel.app",
    status: "failed",
    createdAt: "2024-01-13T09:15:00Z",
    size: "3.2 MB",
  },
]

export default function DeploymentHistory() {
  const [deployments] = useState<Deployment[]>(mockDeployments)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800"
      case "failed":
        return "bg-red-100 text-red-800"
      case "building":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Deployment History</CardTitle>
        <CardDescription>Your recent ZIP deployments</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {deployments.map((deployment) => (
            <div
              key={deployment.id}
              className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileArchive className="h-8 w-8 text-gray-400" />
                <div>
                  <h4 className="font-medium">{deployment.name}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Calendar className="h-3 w-3" />
                    {formatDate(deployment.createdAt)}
                    <span>•</span>
                    <span>{deployment.size}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={getStatusColor(deployment.status)}>{deployment.status}</Badge>
                {deployment.status === "success" && (
                  <Button variant="outline" size="sm" asChild>
                    <a
                      href={deployment.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Visit
                    </a>
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
