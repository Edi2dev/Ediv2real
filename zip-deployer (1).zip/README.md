# TikTok Downloader

Download video TikTok tanpa watermark dengan mudah, cepat, dan gratis.

## Fitur

- ✨ Download tanpa watermark
- 🚀 Proses cepat dan mudah
- 💯 Gratis tanpa batas
- 📱 Responsive untuk semua device
- 🔒 Aman dan privat

## Cara Deploy

### Deploy ke Vercel (Recommended)

1. Fork repository ini
2. Buka [Vercel](https://vercel.com)
3. Import project dari GitHub
4. Deploy otomatis akan berjalan

### Deploy ke Netlify

1. Fork repository ini
2. Buka [Netlify](https://netlify.com)
3. Connect dengan GitHub repository
4. Set build command: `npm run build`
5. Set publish directory: `.next`

### Deploy Manual

\`\`\`bash
# Clone repository
git clone <repository-url>
cd tiktok-downloader

# Install dependencies
npm install

# Build project
npm run build

# Start production server
npm start
\`\`\`

## Development

\`\`\`bash
# Install dependencies
npm install

# Run development server
npm run dev
\`\`\`

## Tech Stack

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- shadcn/ui
- Radix UI

## License

MIT License - Gunakan dengan bijak dan hormati hak cipta.
